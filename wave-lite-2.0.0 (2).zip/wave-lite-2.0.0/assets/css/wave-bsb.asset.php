<?php return array('dependencies' => array(), 'version' => '67057bf33aae26a43cb0');
